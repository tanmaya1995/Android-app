package com.example.tanmaya.abc;

import android.app.Activity;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.app.Activity;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.provider.SyncStateContract.Helpers.insert;

public class MainActivity extends Activity {
    public String str = "";
    Character op = 'q';
    Integer num;
    Integer numtemp;
    EditText showResult;
    private boolean stateError;
    boolean lastDot;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showResult = (EditText) findViewById(R.id.r);
    }

    private void insert(int j) {

        str = str+Integer.toString(j);
        num = Integer.valueOf(Integer.valueOf(str).intValue());
         showResult.setText(str);
    }



    public void btn1(View v) { insert(1); }

    public void btn2(View v){ insert(2); }

    public void btn3(View v){insert(3); }

    public void btn4(View v){ insert(4); }

    public void btn5(View v){ insert(5); }

    public void btn6(View v){ insert(6); }

    public void btn7(View v) { insert(7); }

    public void btn8(View v) { insert(8); }

    public void btn9(View v) { insert(9); }

    public void btn0(View v) { insert(0); }



    private void perform() {
        str = "";
         numtemp=num;
        showResult.setText("" + op);
    }

    public void btnadd(View v){
        perform();
        op = '+';
      //  Toast.makeText(MainActivity.this, "+", Toast.LENGTH_SHORT).show();

        Toast toast = Toast.makeText(getApplicationContext(), "+",
                Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.TOP | Gravity.LEFT, 45, 25);
        toast.show();
        showResult.setText(num + "" + op);
        //showResult.setText(numtemp+"");
    }

    public void btnsub(View v){
        perform();
        op = '-';
        //Toast.makeText(MainActivity.this, "-", Toast.LENGTH_SHORT).show();

            Toast toast = Toast.makeText(getApplicationContext(), "-",
                    Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.LEFT, 45, 25);
            toast.show();
        showResult.setText(num + "" + op+ ""+numtemp+ "");

    }

    public void btnmul(View v){
        perform();
        op = '*';
        //Toast.makeText(MainActivity.this, "*", Toast.LENGTH_SHORT).show();
        Toast toast = Toast.makeText(getApplicationContext(), "*",
                Toast.LENGTH_SHORT);
        //toast.getDuration(1000);
        toast.setGravity(Gravity.TOP | Gravity.LEFT, 45, 25);
        toast.show();
        showResult.setText(num + "" + op + "");
        //showResult.setText(+numtemp+"");
    }

    public void btndiv(View v){
        perform();
        op = '/';
       // Toast.makeText(MainActivity.this, "/", Toast.LENGTH_SHORT).show();
        Toast toast = Toast.makeText(getApplicationContext(), "/",
                Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.TOP | Gravity.LEFT, 45, 25);
        toast.show();
        showResult.setText(num + "" + op);
    }

    public void btndot(View v){ dots();}

    private void dots() {
        if (!(!numtemp || stateError || lastDot)) {

            showResult.append(".");
            lastDot = true;
        }
    }

    public void btnequal(View v){ calculate();
    }

    public void btnclear(View v){ reset(); }

    public void btnclearall(View v){ reseta(); }

    private void reset() {
        str ="";
        op ='q';
        num = Integer.valueOf(0);
        numtemp = Integer.valueOf(0);

        showResult.setText("");

    }

    private void reseta() {
        if (str.length() > 0) {
            str = str.substring(0, str.length() - 1);
            showResult.setText(str);
        } else if (str.length() <=0) {
            showResult.setText("");
        }
    }

    private void calculate() {

        if(op == '+')
            num = numtemp+num;
        else if(op == '-')
            num = numtemp-num;
        else if(op == '*')
            num = numtemp*num;
        else if(op == '/')
            num = numtemp/num;
        showResult.setText(""+num);
    }

    public void setStateError(boolean stateError) {
        this.stateError = stateError;
    }
}



